<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="background" tilewidth="288" tileheight="180" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="288" height="180" source="../stringstar fields/background_0.png"/>
 </tile>
 <tile id="1">
  <image width="288" height="180" source="../stringstar fields/background_1.png"/>
 </tile>
 <tile id="2">
  <image width="288" height="180" source="../stringstar fields/background_2.png"/>
 </tile>
</tileset>
