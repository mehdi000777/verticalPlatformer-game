<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.1" name="springstar" tilewidth="16" tileheight="16" tilecount="198" columns="18">
 <image source="../stringstar fields/tileset.png" width="288" height="176"/>
</tileset>
